import 'package:flutter/material.dart';
import 'package:tictactoe/playing-screen.dart';

class UserAsk extends StatefulWidget {
  UserAsk({Key? key}) : super(key: key);

  @override
  State<UserAsk> createState() => _UserAskState();
}

class _UserAskState extends State<UserAsk> {
  String X = 'X';
  String O = 'O';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(0, 0, 0, 1),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text(
              'Welcome To Chokdi Mindi',
              style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Calibri',
                  color: Colors.white,
                  fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(
            height: 30,
            width: 20,
          ),
          Center(
            child: Text(
              'Choose sign for Player 1',
              style: TextStyle(
                  fontSize: 25,
                  fontFamily: 'Calibri',
                  color: Colors.white,
                  fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(
            height: 30,
            width: 20,
          ),
          Center(
            child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  backgroundColor: Colors.white,
                ),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => PlayingScreen(),
                      settings: RouteSettings(arguments: X),
                    ),
                  );
                },
                child: const Text(
                  'X',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 25,
                    fontFamily: 'Pacifico',
                  ),
                )),
          ),
          SizedBox(
            height: 30,
            width: 20,
          ),
          Center(
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                backgroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const PlayingScreen(),
                    settings: RouteSettings(arguments: O),
                  ),
                );
              },
              child: const Text(
                'O',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 25,
                  fontFamily: 'Calibri',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
