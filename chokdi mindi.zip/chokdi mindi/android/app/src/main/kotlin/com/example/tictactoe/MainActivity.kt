package com.example.tictactoe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
